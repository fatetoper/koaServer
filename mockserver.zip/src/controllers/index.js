let requireDirectory = require('require-directory')
module.exports = requireDirectory(module)